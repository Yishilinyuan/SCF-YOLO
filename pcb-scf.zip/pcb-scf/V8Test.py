# -*- coding = utf-8 -*-
# @Time:  21:10
# @Author:CMDXZ
# @File：V5TestBackbone.py   n  s  m  l
# @Software: PyCharm   https://gitee.com/lyz9900/ultralytics-main-de.git
from ultralytics import YOLO
from loguru import  logger

yaml_file=''
###############1
# 1
yaml_file  = 'yolov8n.yaml'
# 2
yaml_file = 'mobilenet/Replenishment/yolov8l-mobilenet_smallL.yaml'
# 3
yaml_file = 'mobilenet/Replenishment/yolov8l-mobilenetlL-scf.yaml'
############2
yaml_file = 'mobilenet/Replenishment/yolov8s-RepNCSPELAN4.yaml'
#1
yaml_file = 'mobilenet/Replenishment/yolov8-scf.yaml'
#2
yaml_file = 'mobilenet/Replenishment/yolov8s-RepNCSPELAN4-scf.yaml'
#3


# Neck
# yaml_file = 'mobilenet/Replenishment/yolov8-RepNCSPELAN4-CoT.yaml'
#
# yaml_file = 'mobilenet/Replenishment/Neck/yolov8s-RepNCSPELAN4-SPPFCAMSimAM.yaml'
#
# yaml_file = 'mobilenet/Replenishment/Neck/yolov8s-RepNCSPELAN4-SPPF_GAM.yaml'
#
# yaml_file = 'mobilenet/Replenishment/Neck/yolov8s-RepNCSPELAN4-CoT-GhostC2f.yaml'
#
# yaml_file = 'mobilenet/Replenishment/Neck/yolov8s-RepNCSPELAN4-CoT-SCFGhost.yaml'

yaml_file = 'mobilenet/Replenishment/Neck/yolov8s-RepNCSPELAN4-CoT-SCFGhostv2.yaml'
# yaml_file = 'mobilenet/Replenishment/Neck/yolov8s-RepNCSPELAN4-CoT-SCFGhostv3.yaml'
# yaml_file = 'mobilenet/Replenishment/Neck/yolov8s-RepNCSPELAN4-CoT-SCFGhostv4.yaml'
# yaml_file = 'yolov3.yaml'
# yaml_file = 'yolov5s.yaml'
# yaml_file = 'yolov8s.yaml'
model1 = YOLO(yaml_file)
